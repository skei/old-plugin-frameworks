#ifndef axDemo_page_widgets_included
#define axDemo_page_widgets_included
//----------------------------------------------------------------------

#include "wdg/wdgPanel.h"
#include "wdg/wdgLabel.h"
#include "wdg/wdgButton.h"
#include "wdg/wdgValue.h"
#include "wdg/wdgSlider.h"
#include "wdg/wdgScrollBar.h"
#include "wdg/wdgKnob.h"
#include "wdg/wdgOctave.h"
#include "wdg/wdgGrid.h"
#include "wdg/wdgMenuItem.h"

//----------------------------------------------------------------------

////class popupButton : public wdgButton
//class wdgMenuItem : public wdgButton
//{
//  private:
//    bool isHovering;
//    //int  mx,my;
//  public:
//    //popupButton(axWidgetListener* aListener, axRect aRect, int aAlignment=wa_None, axString aText="text", int aTextAlign=ta_Center)
//    wdgMenuItem(axWidgetListener* aListener, axRect aRect, int aAlignment=wa_None, axString aText="text", int aTextAlign=ta_Center)
//    : wdgButton(aListener,aRect,aAlignment,false,aText,aText,aTextAlign,bm_Spring)
//      {
//        isHovering = false;
//      }
//    virtual void doPaint(axCanvas* aCanvas, axRect aRect)
//      {
//        axColor light = aCanvas->getColor(192,192,192);
//        axColor dark  = aCanvas->getColor(64,64,64);
//        axColor grey  = aCanvas->getColor(128,128,128);
//        if (isHovering)
//        {
//          aCanvas->setBrushColor(dark);
//          aCanvas->fillRect(mRect.x,mRect.y,mRect.x2(),mRect.y2());
//          aCanvas->setTextColor(light);
//          aCanvas->drawText(mRect.x,mRect.y,mRect.x2(),mRect.y2(),mOnText,mTextAlign);
//        }
//        else
//        {
//          //aCanvas->setBrushColor(grey);
//          //aCanvas->fillRect(mRect.x,mRect.y,mRect.x2(),mRect.y2());
//          aCanvas->setTextColor(dark);
//          aCanvas->drawText(mRect.x,mRect.y,mRect.x2(),mRect.y2(),mOnText,mTextAlign);
//        }
//      }
//    virtual void doEnter(axWidget* aCapture)
//      {
//        wdgButton::doEnter(aCapture);
//        isHovering = true;
//        mListener->onRedraw(this);
//        //mListener->onCursor(cu_Hand);
//      }
//    virtual void doLeave(axWidget* aCapture)
//      {
//        //mListener->onCursor(DEF_CURSOR);
//        wdgButton::doLeave(aCapture);
//        isHovering = false;
//        mListener->onRedraw(this);
//      }
//};

//----------------------------------------------------------------------

class axDemo_page_widgets : public wdgPanel
{
  // let us access widgets, etc, directly
  friend class axDemo;

  private:
    wdgSizer*     w_Sizer;
    wdgButton*    w1;
    wdgValue*     w2;
    wdgSlider*    w3;
    wdgScrollBar* w4;
    wdgKnob*      w5;
    wdgButton*    bu;
    int           mx,my;
    axWidget*     modal;
    wdgMenuItem   *mi1,*mi2,*mi3,*mi4,*mi5;

  public:

    axDemo_page_widgets(axWidgetListener* aListener, axRect aRect, int aAlignment=wa_None)
    : wdgPanel(aListener,aRect,aAlignment)
      {

        axWidget* widget;
        wdgPanel* panel;
        wdgScrollBox* scroll;

        modal = NULL;
        setBorders(5,5,2,2);
        appendWidget( scroll = new wdgScrollBox(aListener,axRect(0,200),wa_Top) );
          widget = scroll->getContainer();//->setBorders(10,10,5,5);
          //widget->setFlag(wf_Clip);
          scroll->setFlag(wf_Clip);
          widget->setBorders(10,10,5,5);

          widget->appendWidget(      new wdgSlider(    aListener,axRect( 16,200), wa_Left,"v.slider", 0.5, true ) );
          widget->appendWidget(      new wdgLabel(     aListener,axRect(128, 20), wa_Top, "label", ta_Left ) );
          widget->appendWidget( bu = new wdgButton(    this,     axRect(128, 20), wa_Top, false, "spring", "spring", ta_Center, bm_Spring ) );
          widget->appendWidget( w1 = new wdgButton(    aListener,axRect(128, 20), wa_Top, false, "switch", "switch", ta_Center, bm_Switch ) );
          widget->appendWidget( w2 = new wdgValue(     aListener,axRect( 80, 20), wa_TopLeft, "value", 0 ) );
          widget->appendWidget( w3 = new wdgSlider(    aListener,axRect(128, 20), wa_Top, "slider", 0 ) );
          widget->appendWidget( w4 = new wdgScrollBar( aListener,axRect(128, 20), wa_Top  ) );
          widget->appendWidget( w5 = new wdgKnob(      aListener,axRect(128, 32), wa_Top, "knob", 0.3 ) );
          widget->appendWidget(      new wdgKnob(      aListener,axRect(128, 16), wa_Top, "knob", 0.2 ) );
          widget->appendWidget(      new wdgOctave(    aListener,axRect(128, 40), wa_Top  ) );
          widget->appendWidget(      new wdgGrid(      aListener,axRect(128,128), wa_Top) );

        appendWidget( w_Sizer = new wdgSizer(aListener,axRect(0,5),wa_Top,sm_Vertical) );
          w_Sizer->setTarget(scroll);

        appendWidget( panel = new wdgPanel(aListener,axRect(0,100),wa_Client) );
      }

    //----------

    virtual ~axDemo_page_widgets()
      {
      }

    //--------------------------------------------------
    // on..
    //--------------------------------------------------

    virtual void onChange(axWidget* aWidget)
      {
        mListener->onChange(aWidget);
        if (aWidget==bu)
        {
          int x = bu->getRect().x + 5;//0;
          int y = bu->getRect().y + 5;//20;
          modal = new wdgPanel(this,axRect(x,y,80,5*16+10),wa_None);
          modal->setBorders(5,5,0,0);
          modal->appendWidget( mi1 = new wdgMenuItem(this,axRect(0,16),wa_Top,"item 1",ta_Left) );
          modal->appendWidget( mi2 = new wdgMenuItem(this,axRect(0,16),wa_Top,"item 2",ta_Left) );
          modal->appendWidget( mi3 = new wdgMenuItem(this,axRect(0,16),wa_Top,"item 3",ta_Right) );
          modal->appendWidget( mi4 = new wdgMenuItem(this,axRect(0,16),wa_Top,"item 4",ta_Right) );
          modal->appendWidget( mi5 = new wdgMenuItem(this,axRect(0,16),wa_Top,"item 5",ta_Center) );
          modal->doRealign();
          mListener->onCursor(DEF_CURSOR); // ?
          mListener->onModal(true,modal);
        }
        if (aWidget==mi1 || aWidget==mi2 || aWidget==mi3 || aWidget==mi4 || aWidget==mi5)
        {
          int sel = 0;
               if (aWidget==mi1) sel=1;
          else if (aWidget==mi2) sel=2;
          else if (aWidget==mi3) sel=3;
          else if (aWidget==mi4) sel=4;
          else if (aWidget==mi5) sel=5;
          trace("sel: " << sel);
          mListener->onModal(false,NULL);
        }

      }

};

//----------------------------------------------------------------------
#endif
